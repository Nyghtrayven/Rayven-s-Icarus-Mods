Rayven's Stacks 2.5

Version 1.0

Added mammoth tusks to the list. Stacks to 25.