Rayvens Legendaries

Version 1.0

Increased crit/projectile damage of revolver. Increased Projectile damage of bow and added 25% crit chance. Sniper damage increase to projectile damage.