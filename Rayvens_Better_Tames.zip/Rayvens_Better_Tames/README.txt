Rayvens Better Tames

Version 1.0

Increase the xp buff from recently petted animals and raised their max level cap to 100. 
	Future update I plan on adding better stats for the tames. 